<?php
session_start();
if($_SESSION['level'] != "admin"){header("location:../index.php");}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">SISTEM KAMPUS</a>
    <a href="../logout.php" class="btn btn-danger">Logout</a>
  </div>
</nav>

<div class="container mt-4">
    <h2>Selamat Datang Admin</h2>
    <hr>
    <div class="row">
        <div class="col-md-3">
            <div class="card">
                <div class="card-body">
                    <h5>Menu Utama</h5>
                    <a href="data_mahasiswa.php" class="btn btn-primary w-100 mt-2">Data Mahasiswa</a>
                    <a href="data_dosen.php" class="btn btn-primary w-100 mt-2">Data Dosen</a>
                    <a href="data_matkul.php" class="btn btn-primary w-100 mt-2">Mata Kuliah</a>
                    <a href="jadwal.php" class="btn btn-primary w-100 mt-2">Jadwal Kuliah</a>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>